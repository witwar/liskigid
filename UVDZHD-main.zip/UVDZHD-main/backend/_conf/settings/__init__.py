""" Настройки Джанго """

from os import getenv

from split_settings.tools import include, optional


config = [
    'settings.py',
    'static.py',
    'emails.py',
    'metatags.py',
    'images.py',
    'logging.py',
]

if getenv('DEVELOPMENT', None):
    config += [optional('developments.py')]
    print("In development!")
else:
    config += [optional('productions.py')]
    print("In production!")

include(*config)
