""" Настройки версии для разработки """

from .settings import BASE_DIR

DEBUG = True

# Database
# https://docs.djangoproject.com/en/3.1/ref/settings/#databases

DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.sqlite3',
        'NAME': BASE_DIR / '../db.sqlite3',
    }
}

CACHES = {
    'default': {
        'BACKEND': 'django.core.cache.backends.dummy.DummyCache',
    },
    'filecache': {
        'BACKEND': 'django.core.cache.backends.dummy.DummyCache',
    },
}
