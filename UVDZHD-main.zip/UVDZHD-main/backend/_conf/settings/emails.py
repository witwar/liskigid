""" Настройки почты """

DEFAULT_FROM_EMAIL = '"Django" <django@yandex.ru>'
SITE_EMAIL = DEFAULT_FROM_EMAIL
NOTIFY_EMAILS = ['django@gmail.com']

EMAIL_HOST = '127.0.0.1'
EMAIL_HOST_USER = ''
EMAIL_HOST_PASSWORD = ''
EMAIL_PORT = 25
EMAIL_USE_TLS = True
