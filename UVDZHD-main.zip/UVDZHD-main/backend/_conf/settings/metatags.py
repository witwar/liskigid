""" Настройки для Django Meta """

META_SITE_PROTOCOL = 'https'
META_SITE_DOMAIN = 'sitename.ru'
META_USE_TITLE_TAG = True

META_USE_OG_PROPERTIES = True
META_SITE_NAME = 'Название сайта | sitename.ru'
META_INCLUDE_KEYWORDS = ['Ключевые слова']
META_DEFAULT_IMAGE = '/static/build/img/og_image.jpg'
META_DEFAULT_IMAGE_TYPE = 'image/jpeg'
META_FB_TYPES = ['website']
META_SITE_TYPE = 'website'
