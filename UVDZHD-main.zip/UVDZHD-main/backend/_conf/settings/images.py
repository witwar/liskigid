""" Настройки работы с картинками """

from .settings import BASE_DIR

# Настройки для django-resized
DJANGORESIZED_DEFAULT_SIZE = [1600, 1600]
DJANGORESIZED_DEFAULT_QUALITY = 90
DJANGORESIZED_DEFAULT_KEEP_META = False
DJANGORESIZED_DEFAULT_FORCE_FORMAT = 'JPEG'
DJANGORESIZED_DEFAULT_FORMAT_EXTENSIONS = {'JPEG': ".jpg"}
DJANGORESIZED_DEFAULT_NORMALIZE_ROTATION = True

# Настройки для easy_thumbnails
THUMBNAIL_CHECK_CACHE_MISS = True
THUMBNAIL_NAMER= 'easy_thumbnails.namers.source_hashed'
THUMBNAIL_BASEDIR = ''
THUMBNAIL_MEDIA_ROOT = BASE_DIR / 'media.cache'
THUMBNAIL_MEDIA_URL = '/media/cache/'
THUMBNAIL_OPTIMIZE_COMMAND = {
    'png': '/usr/bin/optipng {filename}',
    'gif': '/usr/bin/optipng {filename}',
    'jpeg': '/usr/bin/jpegoptim {filename}'
}

THUMBNAIL_ALIASES = {
    '': {
        'tiny': {
            'size': (0, 48)
        },
        'small': {
            'size': (0, 200)
        },
        'medium': {
            'size': (0, 400)
        },
        'large': {
            'size': (1200, 800)
        },
        'square': {
            'size': (400, 400),
            'crop': True,
            'upscale': True,
        }
    }
}
