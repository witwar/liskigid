""" Настройки для боевой версии """

#from ..settings import BASE_DIR, MIDDLEWARE

DEBUG = False

DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.sqlite3',
        'NAME': '/home/user/sitename.sqlite3',
    }
}

#CSRF_COOKIE_SECURE = True
#SESSION_COOKIE_SECURE = True
#SECURE_SSL_REDIRECT = True

# CACHES = {
#     'default': {
#         'BACKEND': 'django.core.cache.backends.memcached.MemcachedCache',
#         'LOCATION': 'unix:/run/memcached/memcached.sock',
#         'TIMEOUT': 300,
#         'KEY_PREFIX': 'sitename_',
#     },
#     'filecache': {
#         'BACKEND': 'django.core.cache.backends.filebased.FileBasedCache',
#         'LOCATION': '/var/cache/django.sitename',
#     }
# }

# CACHE_MIDDLEWARE_SECONDS = 300
# MIDDLEWARE.insert(0, 'django.middleware.cache.UpdateCacheMiddleware')
# MIDDLEWARE.append('django.middleware.cache.FetchFromCacheMiddleware')
