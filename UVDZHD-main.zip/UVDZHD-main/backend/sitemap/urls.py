from django.views.decorators.cache import cache_page
from django.urls import path
from django.contrib.sitemaps.views import sitemap

from .views import MainSitemap

sitemaps = {
    'sitemaps': {
        'pages': MainSitemap,
    }
}

urlpatterns = [
    path('sitemap.xml', cache_page(14400,  cache='filecache')(sitemap), sitemaps,
        name='django.contrib.sitemaps.views.sitemap'
    )
]
