from django.apps import AppConfig


class SitemapConfig(AppConfig):
    """ Конфигурация приложения Sitemap """
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'sitemap'
