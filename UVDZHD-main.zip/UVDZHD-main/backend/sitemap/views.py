from django.contrib import sitemaps
from django.urls import reverse_lazy

#from pages.urls import urlpatterns as page_urls


class MainSitemap(sitemaps.Sitemap):
    """ Карта сайта для статичных страниц """

    priority = 0.8
    changefreq = 'daily'
    protocol = 'https'

    def items(self):
        # return [f'pages:{x.name}' for x in page_urls]
        return ['pages:main']

    def location(self, item):
        # return reverse_lazy(item)
        return reverse_lazy(item)

    def get_domain(self, site=None):
        return 'railway.r365.ru'
