from django.urls import reverse_lazy
from django.test import Client, TestCase, override_settings

from base.models import Const
#from pages.urls import urlpatterns as pages_urls

TEST_CACHES = {
    'default': {'BACKEND': 'django.core.cache.backends.dummy.DummyCache'},
    'filecache': {'BACKEND': 'django.core.cache.backends.dummy.DummyCache'}
}

class PortfolioTest(TestCase):
    """ Тест карты сайта """

    @override_settings(CACHES=TEST_CACHES)
    def setUp(self):
        # Можно создать объекты в базе, чтобы потом их проверить
        pass

    @override_settings(CACHES=TEST_CACHES)
    def test_sitemap(self):
        """ Проверяем карту сайта """

        #pub_urls = [reverse_lazy(f'pages:{x.name}') for x in pages_urls]
        cli = Client()
        response = cli.get('/sitemap.xml', follow=True)
        self.assertEqual(response.status_code, 200)
