from django.urls import path

from .views import HumanListView


app_name = 'pages'
urlpatterns = [
    path('', HumanListView.as_view(), name="main")
]