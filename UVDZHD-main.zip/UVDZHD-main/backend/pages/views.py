from django.views.generic import ListView
from meta.views import MetadataMixin

from people.models import Human

# Create your views here.
class HumanListView(MetadataMixin, ListView):

    model = Human
    template_name = "pages/main.html"
    context_object_name = 'people'

    title = "ЮВДЖД | 1 смена - оффициальный сайт"
    description = "Оффициальный сайт первой смены Юго-восточной детской железной дороги города Лиски городского парка. ЮВДЖД - это уникальный профориентационный центр, обучающий детей железнодорожным профессиям в формате \"как взрослый\". В РФ открыто и действует около 20 детских железных дорог."
    keywords = ['ювджд', 'юго-восточная', 'детская', 'железная', 'дорога', 'железная дорога', 'юго-восточная железная дорога', 'Лиски железная дорога']
    url = '/'
    locale = 'ru'
