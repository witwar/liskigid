from uuid import uuid4


def uuid_filepath(instance, filename):
    """ Return filepath for image field """
    ext = filename.rsplit('.', 1)[-1]
    name = str(uuid4())
    upload_dir = instance.upload_dir.replace('/', '_')
    return '%s/%s/%s/%s.%s' % (upload_dir, name[0:2], name[2:4], name, ext)
