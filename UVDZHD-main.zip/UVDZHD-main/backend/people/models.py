from django.db import models

from base.models import uuid_filepath


class Role:

    DEFAULT = 0
    STUDENT = 0
    CHIEF = 1
    INSTRUCTOR = 2

    CHOICES = (
        (STUDENT, "Обучающийся"),
        (CHIEF, "Начальник смены"),
        (INSTRUCTOR, "Инструктор"),
    )

    REFERENCES = {
        STUDENT: "Обучающийся",
        CHIEF: "Начальник смены",
        INSTRUCTOR: "Инструктор",
    }

# Create your models here.
class Human(models.Model):
    """Модель человека (работника)."""

    # TODO: Define fields here
    name = models.CharField("ФИО", max_length=255)
    photo = models.ImageField("Фото", upload_to=uuid_filepath)
    year = models.IntegerField("Год обучения", blank=True, null=True)
    role = models.IntegerField("Должность", choices=Role.CHOICES, default=Role.DEFAULT)

    upload_dir = 'people/'

    class Meta:
        """Meta definition for Human."""

        verbose_name = 'Человек'
        verbose_name_plural = 'Люди'

    def __str__(self):
        """Unicode representation of Human."""
        return self.name
    
    def role_str(self):

        return Role.REFERENCES[self.role]

