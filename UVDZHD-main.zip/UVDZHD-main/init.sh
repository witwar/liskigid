#!/bin/bash

npm install --silent && echo 'Gulp with depends has been installed'
gulp build &&  echo 'Static files has been builded to backend/_static/build'
python3 -mvenv env
source env/bin/activate && echo 'Python3 env has been activated from ./env directory'
pip install -Uq pip
pip install -qr requirements.txt && echo 'Pip has been upgraded. Requirements has been installed'
django-admin startproject _conf backend && echo 'Django project has been created on backend directory'
mv backend/_conf/settings.py backend/_conf/settings/ && echo 'Django settings has been moved on settings package'

echo -e 'Apply the README.md to fine tune Django project'
