# django.project

## Что это?

Это заготовка проекта Джанго с установленными пакетами для СЕО, картинок, меню, хлебных крошек, карты сайта. 
В проект внедрен фронтенд сборщик gulp для компиляции CSS, оптимизации картинок, js, сборки спрайтов и шрифтов.
Вся статика собирается в каталог Джанго.

## Развертывание

### Установка и настройка

Для установки Django и Gulp запустите init.sh. Далее нужно выполнить некоторые настройки

    Секретный ключ генерируем командой
    pwgen -syr "\"';,=\`" 64 1

    В .bashrc пишем секретный ключ
    export SECRET_KEY="..."
    
    Для сервера разработки в .bashrc пишем
    export DEVELOPMENT="True"

Далее нужно изменить файл backend/_conf/settings/settings.py

    BASE_DIR = Path(__file__).resolve().parent.parent.parent
    SECRET_KEY = os.getenv('SECRET_KEY')
    DEBUG = False
    ALLOWED_HOSTS = ['*']
    LANGUAGE_CODE = 'ru-ru'
    TIME_ZONE = 'Europe/Moscow'
    SITE_ID = 1

    В TEMPLATES пропишите 'DIRS': ['_templates']
    Удалите STATIC_URL, так как они прописаны в конфиге static.py


Для отдачи загруженных из админки картинок сервером разработки нужно поправить backend/_conf/urls.py

    from django.conf import settings
    from django.conf.urls.static import static
    if settings.DEBUG: urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)


Переименуйте папку проекта на более подходящее вашему проекту название.
Удалите директорию .git, чтобы отвязаться от исходника проекта.
Не забывайте сделать migrate и collectstatic, createsuperuser, чтобы создать окружение Джанго.

А также не забудьте залить проект в github и пушить туда код, чтобы не потерять его в результате форс мажора :-)

## Компиляция и сборка фронтенда в Gulp
Все статичные файлы (css, js, шрифт, картинки, спрайты) собираются в директории src. 
Используя команду gulp build всю статику в минимизированном и собранном-скомпилированном виде мы перенесём в проект Джанго.
Для слежения за изменениями исходников фронтенда и генерации статики в проекте Джанго на лету используем команду gulp без параметров.

## Генерация страниц ошибок для Nginx
В проекте предусмотрены уже скомпилированные стандартные страницы ошибок. Они расположены в backend/_static. Можно сгенерировать кастомные страницы. Для генерации нужен пакет jinja2-cli. Страницы ошибок для Nginx расположены в backend/_static. Исходники для генерации расположены в backend/_templates.
Сгенерировать можно такой командой:

    cd backend/_templates && jinja2 400.html > ../_static/400.html && jinja2 403.html > ../_static/403.html && jinja2 404.html > ../_static/404.html && jinja2 500.html > ../_static/500.html


## Дополнительные пакеты для gulp
- spectre.css - лёгкий CSS фреймворк
- baguettebox.js - лайтбокс галлерея на нативном js

